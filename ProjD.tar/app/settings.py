#/usr/bin/env python
APP_HOST = 'cs3103.cs.unb.ca'
APP_PORT = 34533
APP_DEBUG = True

DB_HOST = 'localhost'
DB_USER = 'pmockler'
DB_PASSWD = 'k84HQFPW'
DB_DATABASE = 'pmockler'

SECRET_KEY = 'd41d8cd98f00b204e9800998ecf8427e'

LDAP_HOST =  'ldap-student.cs.unb.ca'
